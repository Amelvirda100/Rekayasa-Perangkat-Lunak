-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2024 at 07:40 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('Admin1', 'Admin1'),
('Admin2', 'Admin2');

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

CREATE TABLE `anggota` (
  `id_anggota` int(11) NOT NULL,
  `kode_anggota` varchar(10) NOT NULL,
  `nama_anggota` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `no_telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `anggota`
--

INSERT INTO `anggota` (`id_anggota`, `kode_anggota`, `nama_anggota`, `jenis_kelamin`, `no_telp`) VALUES
(1, 'ANG-001', 'Rolly Dhea', 'P', '081234567888'),
(2, 'ANG-002', 'Virda Stefany', 'P', '087771234567'),
(3, 'ANG-003', 'Caecilia Glory', 'P', '082134567891'),
(4, 'ANG-004', 'Rafa Wega', 'L', '087879767473'),
(5, 'ANG-005', 'Alfin', 'L', '081512345678');

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(11) NOT NULL,
  `kode_buku` varchar(10) NOT NULL,
  `judul_buku` varchar(50) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `pengarang` varchar(50) NOT NULL,
  `penerbit` varchar(50) NOT NULL,
  `thn_terbit` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  `sinopsis` text NOT NULL,
  `id_rak` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `kode_buku`, `judul_buku`, `kategori`, `pengarang`, `penerbit`, `thn_terbit`, `stok`, `sinopsis`, `id_rak`) VALUES
(1, 'BHS-001', 'Buku Praktis Belajar Bahasa Inggris', 'Bahasa', 'Wahida Murriska', 'CHECKLIST', 2014, 5, 'Anda dapat meningkatkan kemampuan bahasa Inggris Anda dengan cara yang efektif tanpa mengeluarkan banyak uang atau waktu dengan mengikuti kursus tatap muka. Cukup dengan membeli buku yang terpercaya, Anda bisa mengasah kemampuan bahasa Inggris secara mandiri. Hal ini dapat bermanfaat dalam berbagai situasi seperti mencari pekerjaan, mendaftar perguruan tinggi, atau mengikuti seleksi beasiswa. Ada banyak jenis buku belajar bahasa Inggris yang direkomendasikan mulai dari dasar hingga persiapan tes TOEFL. Salah satu buku yang bisa Anda pertimbangkan adalah \"Buku Praktis Belajar Bahasa Inggris\" karya Wahida Murriska. Buku ini cocok untuk pemula maupun untuk orang yang ingin memperbaiki kemampuan bahasa Inggris mereka dalam berbicara dan menulis. Isinya mencakup berbagai metode pembelajaran, seperti pengulangan, peniruan, deskripsi gambar, dan bercerita ulang, yang dapat membantu Anda mengembangkan kemampuan bahasa Inggris secara alami.', 3),
(2, 'BHS-002', 'Menuju Top Skor TOEFL', 'Bahasa', 'Tangguh Okta W.', 'Diva Press Group', 2018, 3, 'TOEFL adalah singkatan dari Test Of English as a Foreign Language, yang merupakan tes standar bahasa Inggris secara internasional dan penting untuk masuk ke institusi pemerintah, lembaga, dan universitas. Banyak perusahaan internasional menggunakan skor TOEFL sebagai syarat perekrutan. Belajar bahasa Inggris untuk TOEFL memerlukan intensitas belajar yang tinggi, dan buku latihan persiapan TOEFL dapat membantu mempercepat proses pembelajaran.\r\nBanyak buku latihan TOEFL di pasaran, tetapi sebagian besar terlalu berfokus pada soal-soal, tanpa memperhatikan pemahaman konsep dasar bahasa Inggris pembaca. Untuk memudahkan pembelajaran, buku ini disusun dengan fokus pada persiapan menghadapi TOEFL, terutama pada bagian struktur dan ekspresi tertulis. Buku ini mencakup 14 bab yang membahas teknik-teknik percepatan dalam menjawab soal-soal TOEFL.\r\n', 3),
(3, 'BHS-003', 'Trik Cepat Kuasai Bahasa Korea', 'Bahasa', 'Melia Lee', 'Thema Publishing', 2021, 4, 'Bahasa Korea menjadi populer berkat K-Pop dan drama-drama Korea yang sedang booming. Buku ini dirancang khusus untuk pemula agar mudah belajar bahasa Korea, dengan pembahasan tentang dasar-dasar bahasa, tata bahasa, kosakata, dan percakapan. Manfaat mempelajari bahasa Korea antara lain:\r\n1. Memahami Konteks Budaya Korea: Bahasa adalah kunci untuk memahami budaya. Untuk penggemar drama Korea, belajar bahasa Korea membantu memahami cerita secara lebih dalam dan menikmati hiburan Korea dengan lebih baik.\r\n2. Akses Pendidikan Berkualitas: Beberapa universitas Korea Selatan terkenal dengan keunggulan teknologi, seperti KAIST dan POSTECH. Kemampuan berbahasa Korea diperlukan untuk kuliah di sana, yang dapat membuka peluang untuk belajar di institusi ternama dan terlibat dalam industri teknologi yang berkembang pesat di Korea Selatan.\r\n', 3),
(4, 'BHS-004', 'Ternyata Bahasa Mandarin Mudah', 'Bahasa', 'El Sami’un Dani Bao', 'Solusi Distribusi Buku Cv', 2019, 2, 'Bahasa Mandarin menjadi salah satu bahasa yang paling diminati untuk dipelajari di Indonesia. Di sekolah-sekolah sudah banyak yang menjadikan bahasa Mandarin sebagai bagian dari mata pelajaran, bahkan di beberapa kampus, bahasa Mandarin dijadikan sebagai pilihan jurusan yang ada dan berdiri sendiri. Pada saat ini banyak perusahaan menuntut bisa menggunakan bahasa Mandarin, hal tersebut bukan karena pemilik perusahaan merupakan orang China, tapi juga karena sebagian perusahaan melakukan kerjasama dengan perusahaan China. Keberadaan bahasa Mandarin di Indonesia sangat mempunyai dampak yang baik, dari berdampak pada pasar perdagangan hingga pada beasiswa. Maka dari itu semakin banyak yang ingin belajar bahasa Mandarin karena hal-hal tersebut. Akan tetapi belajar bahasa Mandarin bukanlah hal yang mudah karena bahasa Mandarin merupakan salah satu bahasa tersulit di dunia karena penulisannya yang berbeda dengan bahasa lain.\r\nBuku Ternyata Bahasa Mandarin Mudah ini hadir untuk membantu orang-orang yang akan dan sedang belajar bahasa Mandarin. Dengan buku ini, membuat belajar bahasa Mandarin yang awalnya terlihat sulit menjadi lebih mudah dan menyenangkan. Jadi tidak ada alasan lagi untuk kesulitan dalam mempelajarinya. Cocok untuk pemula hingga mahir.\r\n', 3),
(5, 'BHS-005', 'Mari Belajar Bahasa Jepang', 'Bahasa', 'Nina Kirana', 'Bitread Digital Publishing', 2018, 4, 'Di era globalisasi ini kebutuhan untuk menguasai bahasa asing telah menjadi tuntutan bagi seluruh masyarakat dunia agar dapat berkompetisi dalam persaingan global. Selain bahasa Inggris, bahasa Jepang merupakan salah satu bahasa yang penting untuk dikuasai karena banyak manfaat yang bisa didapat dari menguasai bahasa Jepang. Atas dasar itu buku ini disusun sebagai panduan bagi siapa pun yang ingin belajar bahasa Jepang dengan cepat dan mudah. Buku \"Mari Belajar Bahasa Jepang\" ini disusun sedemikian rupa, sehingga menjadikannya sebuah buku panduan dalam mempelajari bahasa Jepang. Sangat bermanfaat bagi Anda yang ingin/sedang belajar bahasa Jepang, akan pergi ke Negeri Matahari Terbit, atau Anda yang menyukai segala hal yang bertema Jepang. Buku ini memberikan panduan bagaimana melakukan percapakan sehari-hari yang meliputi salam dan perkenalan, kata penanya, kalimat negatif, serta ungkapan permintaan atau larangan. Selain menggunakan aksara Jepang, buku ini dilengkapi dengan tulisan latin agar memudahkan untuk membacanya. Jika Anda ingin mulai belajar dan menguasai bahasa Jepang maka buku ini wajib Anda miliki.', 3),
(6, 'RF-001', 'Super Trik: Sukses & Kaya Raya Ala Mark Zuckerberg', 'Referensi', 'Desi Setianingsih', 'Scritto Books', 2019, 3, '\"Super Trik: Sukses & Kaya Raya Ala Mark Zuckerberg\" membahas kehidupan dan kesuksesan Mark Zuckerberg, pendiri Facebook. Buku ini mengungkap sisi lain dari Zuckerberg, termasuk konflik-konflik yang dia alami, dan memberikan tips sukses ala Zuckerberg. Buku ini bertujuan memberikan inspirasi dan semangat kepada pembaca untuk mengejar mimpi dan cita-cita mereka. Kamu bisa mendapatkannya di Gramedia.', 2),
(7, 'RF-002', 'Change Your Habits, Change Your Life', 'Referensi', 'Yodhia Antariksa', 'Checklist ', 2023, 3, 'Apakah Anda punya kebiasaan? Apa saja kebiasaan itu? Baikkah atau burukkah? Atau Anda malah tidak sadar bahwa sebenarnya Anda memiliki kebiasaan?\r\nPerubahan dalam kehidupan merupakan sesuatu yang penting guna mengimbangi terjadinya perubahan zaman. Perubahan kehidupan ini merujuk pada perubahan signifikan dan berkelanjutan dalam kehidupan seseorang. Perubahan Ini melibatkan pergeseran dalam pola pikir, perilaku, atau keadaan yang mengarah pada pengalaman hidup yang positif dan memuaskan. Perubahan kehidupan bisa menantang dan memerlukan usaha serta komitmen, tetapi hadiahnya seringkali signifikan. Ini dapat membawa kebahagiaan yang lebih besar, kepuasan, dan rasa memiliki tujuan yang lebih jelas dalam hidup. Melakukan perubahan besar dalam hidup dapat dimulai dari sesuatu yang kecil yaitu perubahan kebiasaan. Jika dilakukan secara konsisten, perubahan kebiasaan ini memiliki kekuatan yang luar biasa pada kehidupan. Dalam buku ini, kita akan menemukan bagaimana kebiasaan yang kita kembangkan dapat berdampak besar pada kesejahteraan dan kesuksesan kita secara keseluruhan. Dengan memahami ilmu di balik pembentukan kebiasaan dan memanfaatkan strategi yang tepat, kita dapat melepaskan diri dari pola negatif dan menggantinya dengan kebiasaan positif yang sejalan dengan tujuan kita.\r\nSesungguhnya, bagaimana hidup saat ini dan masa depan kita ditentukan oleh kebiasaan kita. Jika kebiasaan kita produktif dan berfaedah, maka hidup kita pun pasti menakjubkan. Sebaliknya, jika yang ada kebiasaan buruk dan destruktif, maka kita harus bersiap mengarungi jalan hidup yang terjal.\r\nNamun, mengubah kebiasaan menjadi baik memang tidak semudah diucapkan. Pasti aka nada alang rintang yang mengadang. Oleh karena itu, buku ini ditorehkan demi membantu mewujudkan kebiasaan baik dalam keseharian. Bersama-sama, dengan kiat yang praktis dan bertahap, diri akan merasakan perubahan.\r\nMari, mulai dan tekuni kebiasaan baik sejak sekarang, dan rasakan impaknya dalam hidup yang gemilang.\r\n', 2),
(8, 'BHS-006', 'TOEFL Grammar Perfect Score', 'Bahasa', 'Rosyid Anwar', 'Bhuana Ilmu Populer', 2022, 4, 'TOEFL merupakan tes kemampuan bahasa Inggris yang seringkali diperlukan untuk mendaftar masuk ke universitas di Amerika Serikat atau negara-negara lain di dunia. Tes ini menjadi persyaratan bagi pendaftar dengan bahasa Inggris bukan sebagai bahasa ibu. Banyak orang yang kesulitan menjawab soal-soal TOEFL karena kurangnya pemahaman dan kehabisan waktu untuk menjawab. Tes Structure and Written Expression merupakan bagian tes TOEFL yang sulit. Buku ini dirancang untuk membantu pembaca mempersiapkan diri menghadapi tes Structure and Written Expression TOEFL. TOEFL Grammar Perfect Score adalah buku yang mempelajari bagian tes Structure and Written Expression dengan pembahasan lengkap, disertai pendekatan menganalisis materi dan contoh pertanyaan.\r\nBuku ini berisi: Pre-Test; Materi yang lengkap, komprehensif, dan mendalam; Materi disajikan berurutan mulai dari English words, word formation, English phrase, English clause, dan English sentence; menyajikan penjelasan mengenai aturan pengecualian (key exceptions), kesalahan gramatikal (common grammatical errors), grammatical inconsistencies, serta problems with usage; strategi meliputi yang aspek gramatikal, aspek komunikatif, dan strategi alternatif; terdapat contoh soal Structure and Written Expression TOEFL beserta pembahasan lengkap. Pada setiap bab, Anda dapat menguji penguasaan terhadap materi dalam sesi Latihan yang terdiri dari latihan-latihan singkat. Terdapat 5 Practice Test (200 soal) yang akan menguji pemahaman materi Anda. Pada bagian akhir buku, Anda dapat melakukan evaluasi hasil belajar dengan mengerjakan Post-Test.\r\n', 3),
(9, 'MSK-001', 'Estetika Musik Dalam Peradaban Barat', 'Musik', 'Sunarto', 'Thafa Media', 2021, 3, 'Bagaimana bisa seseorang mendefinisikan sebuah kecantikan ?\r\nBagaimana pula keahlian menjadi sebuah seni ?\r\nApa yang terdapat dalam karya besar dalam dunia musik ?\r\nPertanyaan ini selalu menjadi pembicaraan yang serius selama berabad-abad, dan sanggahan pun selalu bermunculan. Estetika [yunani, Aesthesis, rasa, sensasi] secara umum dapat diartikan sebagai filosofi atau ilmu dari sebuah kecantikan. Estetika adalah istilah umum yang diciptakan untuk menggambarkan refleksi filosofis seni, termasuk musik.\r\nSebuah estetika musik mengajukan beberapa pertanyaan mendasar tentang subjek, seperti: apa artinya musik? posisi individual dan keyakinan dapat digambarkan sebagai estetika. hal ini jg diartikan dg ideologi dalam sekumpulan keyakinan spesifik dimana terletak tanggapan dan interpretasi estetika tertentu dan juga dapat mendikte sifat pertanyaan yang diajukan tentang musik. Dalam estetika musik terdapat dua pandangan yang selalu diperbincangkan, yaitu: 1] Musik adalah seni heteronomous dan dapat mengekspresikan unsur2 tambahan musik; 2] Musik adalah seni autonomous yg mampu merealisasikan ide-ide prinsip hakikinya.\r\nSejarah musik Barat merupakan patokan utama dalam seni musik dunia karena tradisi musik Baratlah yang hingga kini mempengaruhi dunia modern. Oleh karena itu, saat kita mempelajari sejarah musik Barat, hampir dapat dikatakan pula bahwa kita sedang mempelajari sejarah musik dunia. Toh pada akhirnya musik itu bersifat universal. Setiap orang, dari manapun asalnya, akan mampu mencerna, memahami, dan menikmati musik tanpa harus mengenal, mengerti, dan memahami bahasa lirik yang digunakan penciptanya.\r\n', 4),
(10, 'MSK-002', 'Psikologi Musik', 'Musik', 'Djohan', 'Pt Kasinius', 2020, 2, 'Psikologi dan musikologi merupakan dua cabang ilmu pengetahuan tua, yang satu mendalami perilaku manusia dan satunya lagi memaparkan hasil/produk dari perilaku tersebut. Kedua elemen tersebut pada prinsipnya tidak terpisahkan karena saat ini telah banyak penelitian interdisiplin yang hasilnya memberikan sumbangsih positif dalam kehidupan sehari-hari. Oleh karena itu, penulis berupaya mendiseminasikan psikologi musik sebagai pengetahuan yang relatif masih baru di Indonesia ini kepada berbagai kalangan. Penulis tidak bermaksud menggambarkan seluruh bidang psikologi musik secara detail karena pembahasan setiap topik memerlukan pendalaman tersendiri. Oleh sebab itu, buku ini hanya mengikhtisarkan beberapa topik utama dan aktual dalam bidang psikologi musik. Selain itu, penulis secara khusus memberi perhatian pada persoalan psikologi dan musik yang sangat relevan untuk dikaji dan diambil manfaatnya. Buku Psikologi Musik ini merupakan wacana awal dengan tujuan memberikan informasi standar serta sebagai stimulan bagi pembaca, baik dosen, mahasiswa, peneliti, maupun siapa pun yang memiliki minat untuk mempelajari dan melakukan penelitian lebih lanjut. Di samping sebagai buku acuan bagi pakar psikologi dan musik, buku ini dapat menjadi dasar pengetahuan psikologi musik dengan berbagai pendekatan teoritis untuk menuju praktikum aplikatif. Penulis berharap, kelak bidang psikologi musik di Indonesia dengan objek materi berlandaskan filosofi nusantara dapat melengkapi pengetahuan sosiohumaniora secara lebih luas.', 4);

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id_peminjaman` int(11) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `id_buku` int(11) NOT NULL,
  `id_anggota` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengembalian`
--

CREATE TABLE `pengembalian` (
  `id_pengembalian` int(11) NOT NULL,
  `tgl_pengembalian` date NOT NULL,
  `denda` int(20) NOT NULL,
  `id_buku` int(11) NOT NULL,
  `id_anggota` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rak`
--

CREATE TABLE `rak` (
  `id_rak` int(11) NOT NULL,
  `nama_rak` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rak`
--

INSERT INTO `rak` (`id_rak`, `nama_rak`) VALUES
(1, 'Belajar Umum'),
(2, 'Buku Referensi'),
(3, 'Sastra dan Bahasa'),
(4, 'Seni dan Musik'),
(5, 'Sains dan Teknologi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id_anggota`);

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`),
  ADD KEY `id_rak` (`id_rak`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id_peminjaman`),
  ADD KEY `id_buku` (`id_buku`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Indexes for table `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD PRIMARY KEY (`id_pengembalian`),
  ADD KEY `id_buku` (`id_buku`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Indexes for table `rak`
--
ALTER TABLE `rak`
  ADD PRIMARY KEY (`id_rak`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anggota`
--
ALTER TABLE `anggota`
  MODIFY `id_anggota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id_peminjaman` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengembalian`
--
ALTER TABLE `pengembalian`
  MODIFY `id_pengembalian` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rak`
--
ALTER TABLE `rak`
  MODIFY `id_rak` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `buku_ibfk_1` FOREIGN KEY (`id_rak`) REFERENCES `rak` (`id_rak`);

--
-- Constraints for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`),
  ADD CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`id_anggota`) REFERENCES `anggota` (`id_anggota`);

--
-- Constraints for table `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD CONSTRAINT `pengembalian_ibfk_1` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`),
  ADD CONSTRAINT `pengembalian_ibfk_2` FOREIGN KEY (`id_anggota`) REFERENCES `anggota` (`id_anggota`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
