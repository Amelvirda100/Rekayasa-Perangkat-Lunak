<?php
require 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    
    $query = "SELECT * FROM admin WHERE username = '$username'";
    $result = mysqli_query($connect, $query);

    if (mysqli_num_rows($result) > 0) {
        header("Location: form_signup.php?error=1");
        exit;
    }
    elseif($password !== $cpassword){
        header("Location: form_signup.php?error=3");
        exit();
    }
    else {
        $query = "INSERT INTO admin (username, password) VALUES ('$username', '$password')";
        $insertResult = mysqli_query($connect, $query);

        if ($insertResult) {
            header("Location: login.php");
            exit;
        } else {
            header("Location: form_signup.php?error=2");
            exit();
        }
    }
}

?>